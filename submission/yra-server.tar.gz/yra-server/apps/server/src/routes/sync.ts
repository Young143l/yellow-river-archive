/**
 * 同步服务：WebSocket 通道 + 配对码接口。
 *
 * 为什么同步用 WS 而不是 HTTP：
 *   1. 推送是双向的 —— 设备 A 改了数据，设备 B 需要被及时通知，HTTP 只能轮询
 *   2. 握手时带上身份，后续每次推拉不必重复鉴权与建连
 *
 * 通道定位（ADR-009）：这是**兜底通道**。主路径是鸿蒙分布式数据服务，
 * 它在同账号信任环内可用时更快且不依赖服务器。云端通道的价值在于
 * 「跨网络、路演第二设备、真机数量不足」这些分布式软总线覆盖不到的场景。
 */

import type { FastifyInstance, FastifyPluginAsync } from 'fastify'
import websocket from '@fastify/websocket'

import type {
  ApiError,
  ChangeSet,
  ConflictRecord,
  MsgError,
  SyncableRecord,
  SyncClientMessage,
  SyncPull,
  SyncPush,
  SyncServerMessage,
} from '@yra/shared'
import type { WebSocket } from 'ws'

import type { Db } from '../db/index'
import { createSnapshot, deleteSnapshot, listSnapshots, readSnapshotForRestore, snapshotStats } from '../sync/backup'
import { listDevices, touchDevice } from '../sync/devices'
import { isAccountUser } from '../auth/store'
import { applyPull, applyPush, currentCursor, userStats } from '../sync/store'

export interface SyncRouteOptions {
  readonly db: Db
}

interface SyncConnectionQuery {
  readonly userId?: string
  readonly deviceId?: string
  readonly deviceName?: string
}

/** 同一用户的所有活跃连接，用于把变更广播给其他设备 */
const rooms = new Map<string, Set<WebSocket>>()

function joinRoom(userId: string, socket: WebSocket): void {
  const set: Set<WebSocket> = rooms.get(userId) ?? new Set<WebSocket>()
  set.add(socket)
  rooms.set(userId, set)
}

function leaveRoom(userId: string, socket: WebSocket): void {
  const set: Set<WebSocket> | undefined = rooms.get(userId)
  if (set === undefined) {
    return
  }
  set.delete(socket)
  if (set.size === 0) {
    rooms.delete(userId)
  }
}

/** 广播给同一用户的其他设备（不回声给来源设备，否则会造成回环推送） */
function broadcast(userId: string, from: WebSocket, message: SyncServerMessage): void {
  const set: Set<WebSocket> | undefined = rooms.get(userId)
  if (set === undefined) {
    return
  }
  const payload: string = JSON.stringify(message)
  for (const socket of set) {
    if (socket !== from && socket.readyState === 1) {
      socket.send(payload)
    }
  }
}

function errorMessage(code: string, message: string): MsgError {
  return { type: 'error', code, message }
}

export const syncRoutes: FastifyPluginAsync<SyncRouteOptions> = async (
  app: FastifyInstance,
  options: SyncRouteOptions
) => {
  const { db } = options

  // 配对码已退役（ADR-044）：身份一律走 /api/auth

  await app.register(websocket)

  // -------------------------------------------------------------------------
  // 账号准入（ADR-044：配对码退役，云端身份一律走 /api/auth）
  // -------------------------------------------------------------------------

  /** 未登录（userId 不属于任何账号）时的统一 401 应答 */
  const unauthorized = (reply: { code: (n: number) => { send: (b: ApiError) => object } }): object =>
    reply.code(401).send({ code: 'E4012', message: '请先登录' })

  app.get<{ Querystring: { userId?: string } }>('/api/sync/devices', async (request, reply) => {
    const userId: string = request.query.userId ?? ''
    if (!isAccountUser(db, userId)) {
      return unauthorized(reply)
    }
    if (userId.length === 0) {
      const e: ApiError = { code: 'E4002', message: '需要 userId' }
      return reply.code(400).send(e)
    }
    return { userId, devices: listDevices(db, userId), ...userStats(db, userId) }
  })

  // -------------------------------------------------------------------------
  // 云端快照（备份点，D4-10）
  // -------------------------------------------------------------------------

  app.post<{ Body: { userId?: string } }>('/api/backup/snapshot', async (request, reply) => {
    const userId: string = (request.body?.userId ?? '').trim()
    if (!isAccountUser(db, userId)) {
      return unauthorized(reply)
    }
    if (userId.length === 0) {
      const e: ApiError = { code: 'E4002', message: '需要 userId' }
      return reply.code(400).send(e)
    }
    const result = createSnapshot(db, userId)
    if (!result.ok) {
      const e: ApiError = { code: 'E4008', message: result.message }
      return reply.code(400).send(e)
    }
    return result
  })

  app.get<{ Querystring: { userId?: string; limit?: string } }>(
    '/api/backup/snapshots',
    async (request, reply) => {
      const userId: string = (request.query.userId ?? '').trim()
      if (!isAccountUser(db, userId)) {
        return unauthorized(reply)
      }
      if (userId.length === 0) {
        const e: ApiError = { code: 'E4002', message: '需要 userId' }
        return reply.code(400).send(e)
      }
      const rawLimit: string | undefined = request.query.limit
      const limit: number = rawLimit !== undefined ? Number.parseInt(rawLimit, 10) : 20
      const safeLimit: number = Number.isFinite(limit) && limit > 0 && limit <= 100 ? limit : 20
      const stats = snapshotStats(db, userId)
      return {
        userId,
        snapshots: listSnapshots(db, userId, safeLimit),
        count: stats.count,
        totalBytes: stats.totalBytes,
      }
    }
  )

  app.post<{ Params: { id: string }; Body: { userId?: string } }>(
    '/api/backup/snapshots/:id/restore',
    async (request, reply) => {
      const userId: string = (request.body?.userId ?? '').trim()
      if (!isAccountUser(db, userId)) {
        return unauthorized(reply)
      }
      if (userId.length === 0) {
        const e: ApiError = { code: 'E4002', message: '需要 userId' }
        return reply.code(400).send(e)
      }
      const result = readSnapshotForRestore(db, userId, request.params.id)
      if (!result.ok) {
        const e: ApiError = { code: 'E4009', message: result.message }
        return reply.code(404).send(e)
      }
      // 返回变更集而不直接改服务端数据 —— 由客户端走 LWW 合并落库
      return { ok: true, message: result.message, changes: result.changes }
    }
  )

  app.delete<{ Params: { id: string }; Querystring: { userId?: string } }>(
    '/api/backup/snapshots/:id',
    async (request, reply) => {
      const userId: string = (request.query.userId ?? '').trim()
      if (!isAccountUser(db, userId)) {
        return unauthorized(reply)
      }
      if (userId.length === 0) {
        const e: ApiError = { code: 'E4002', message: '需要 userId' }
        return reply.code(400).send(e)
      }
      const removed: boolean = deleteSnapshot(db, userId, request.params.id)
      return { ok: removed, message: removed ? '已删除' : '快照不存在' }
    }
  )

  // -------------------------------------------------------------------------
  // 同步通道（WebSocket）
  // -------------------------------------------------------------------------

  app.get<{ Querystring: SyncConnectionQuery }>(
    '/api/sync',
    { websocket: true },
    (socket: WebSocket, request) => {
      const userId: string = (request.query.userId ?? '').trim()
      const deviceId: string = (request.query.deviceId ?? '').trim()
      const deviceName: string = (request.query.deviceName ?? '').trim()

      if (userId.length === 0 || deviceId.length === 0) {
        socket.send(JSON.stringify(errorMessage('E4002', '连接需要 userId 与 deviceId 参数')))
        socket.close()
        return
      }
      // ADR-044：云端同步只认账号。未注册的 userId 一律拒绝 ——
      // 之前不校验，任何人带上别人的 userId 就能读写那个房间
      if (!isAccountUser(db, userId)) {
        socket.send(JSON.stringify(errorMessage('E4012', '请先登录')))
        socket.close()
        return
      }

      touchDevice(db, userId, deviceId, deviceName)
      joinRoom(userId, socket)
      app.log.info(`同步连接建立：user=${userId.slice(0, 12)}… device=${deviceId.slice(0, 8)}…`)

      // 建连即回报当前游标与状态，客户端据此决定是否需要拉取
      const initial: SyncServerMessage = {
        type: 'state',
        state: 'idle',
      }
      socket.send(
        JSON.stringify({
          ...initial,
          cursor: currentCursor(db, userId),
        })
      )

      socket.on('message', (raw: Buffer) => {
        let message: SyncClientMessage
        try {
          message = JSON.parse(raw.toString()) as SyncClientMessage
        } catch (err) {
          socket.send(JSON.stringify(errorMessage('E4004', '消息不是合法 JSON')))
          return
        }

        if (message.type === 'push') {
          handlePush(socket, message)
        } else if (message.type === 'pull') {
          handlePull(socket, message)
        } else {
          socket.send(JSON.stringify(errorMessage('E4005', `未知消息类型`)))
        }
      })

      socket.on('close', () => {
        leaveRoom(userId, socket)
      })

      socket.on('error', () => {
        leaveRoom(userId, socket)
      })

      // ---- 处理函数 ----

      function handlePush(socket: WebSocket, message: SyncPush): void {
        try {
          // 进度消息：分批发送，客户端进度条才会动。
          // 之前只发一条 done:0 就在一个事务里全写完再发 applied，
          // 中间没有任何增量，进度条永远停在 0 —— 等于没画。
          const total: number = countRecords(message.changes)
          const direction: string = '正在上传到云端'
          const sendProgress = (done: number): void => {
            socket.send(JSON.stringify({ type: 'progress', done, total, direction }))
          }
          sendProgress(0)

          // 按表分批：每批一个事务，批间发一次累加进度。
          // 单表超过 BATCH_SIZE 再切，避免一条长笔记流把批次撑得过大
          const BATCH_SIZE: number = 20
          const batches: { table: string; records: SyncableRecord[] }[] = []
          for (const set of message.changes) {
            for (let i = 0; i < set.records.length; i += BATCH_SIZE) {
              batches.push({ table: set.table, records: set.records.slice(i, i + BATCH_SIZE) })
            }
          }

          let applied = 0
          const conflicts: ConflictRecord[] = []
          let done = 0
          for (const batch of batches) {
            const r = applyPush(db, userId, [{ table: batch.table, records: batch.records }])
            applied += r.applied
            conflicts.push(...r.conflicts)
            done += batch.records.length
            sendProgress(Math.min(done, total))
          }

          socket.send(
            JSON.stringify({
              type: 'applied',
              applied,
              conflicts,
            })
          )

          // 服务端存的是权威版本，因此推来的变更也要广播给同用户的其他设备。
          // 不广播的话，三台设备两两同步的延迟会叠加。
          if (applied > 0) {
            broadcast(userId, socket, {
              type: 'pulled',
              changes: message.changes,
              conflicts,
              cursor: currentCursor(db, userId),
              serverTime: Date.now(),
            } as SyncServerMessage)
          }
        } catch (err) {
          socket.send(
            JSON.stringify(errorMessage('E4006', `推送失败：${(err as Error).message.slice(0, 120)}`))
          )
        }
      }

      function handlePull(socket: WebSocket, message: SyncPull): void {
        try {
          socket.send(
            JSON.stringify({ type: 'progress', done: 0, total: 1, direction: '正在从云端取回' })
          )
          const result = applyPull(db, userId, message.since, message.deviceId)
          socket.send(
            JSON.stringify({ type: 'progress', done: 1, total: 1, direction: '正在从云端取回' })
          )
          socket.send(
            JSON.stringify({
              type: 'pulled',
              changes: result.changes,
              conflicts: result.conflicts,
              cursor: result.cursor,
              serverTime: Date.now(),
            })
          )
        } catch (err) {
          socket.send(
            JSON.stringify(errorMessage('E4007', `拉取失败：${(err as Error).message.slice(0, 120)}`))
          )
        }
      }
    }
  )
}

function countRecords(changes: readonly ChangeSet[]): number {
  let total: number = 0
  for (const set of changes) {
    total += set.records.length
  }
  return total
}

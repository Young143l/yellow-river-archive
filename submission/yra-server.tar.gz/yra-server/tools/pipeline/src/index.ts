/**
 * 数据流水线 CLI。
 *
 *   pnpm data:build    校验 + 分块 + 构图 + 预计算 + 导出端侧预置包
 *   pnpm data:status   只做校验与分布统计（不写文件）
 *   pnpm data:verify   严格校验，有问题则退出码非零（pre-push / CI 用）
 *
 * 本文件只做编排，具体步骤在各自模块里。
 */

import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

import { buildChunks } from './chunk'
import { generateCovers, fixImageCredit, type CoverReport } from './covers'
import { fetchSources, type SourceReport } from './fetch-source'
import { promoteAll, type PromoteReport } from './promote'
import { rewriteAll, type RewriteReport } from './rewrite'
import { runEmbedding, type EmbedReport } from './embed'
import { exportPreset } from './export'
import { buildGraph } from './graph'
import { computeDistribution, loadSites, type Distribution, type LoadIssue } from './load-sites'
import { buildSimilar } from './similar'
import { draftAll, type DraftReport, type DraftTarget } from './draft'
import { loadSitesDoc, reportSites, type SitesReport } from './sites'
import {
  lintAll,
  lintChunks,
  lintVocab,
  type LintIssue,
  type LintReport,
} from './lint'
import {
  buildVocab,
  extractTermsFromItems,
  loadLexicon,
  Tokenizer,
  type VocabEntry,
} from './tokenize'

const HERE: string = dirname(fileURLToPath(import.meta.url))
const REPO_ROOT: string = resolve(HERE, '..', '..', '..')
const SITES_DIR: string = join(REPO_ROOT, 'packages', 'data', 'sites')
const SITES_INDEX: string = join(REPO_ROOT, 'packages', 'data', 'sites.yaml')
const SOURCES_DIR: string = join(REPO_ROOT, 'packages', 'data', 'sources')
const LEXICON: string = join(REPO_ROOT, 'packages', 'data', 'lexicon.txt')
const DRAFTS_DIR: string = join(REPO_ROOT, 'packages', 'data', 'drafts')
const RAWFILE_DIR: string = join(
  REPO_ROOT,
  'harmony',
  'YellowRiverArchive',
  'entry',
  'src',
  'main',
  'resources',
  'rawfile'
)
const FONT: string = join(RAWFILE_DIR, 'fonts', 'NotoSerifSC-SemiBold.ttf')
const PAPER: string = join(RAWFILE_DIR, 'img', 'paper.webp')
const IMG_DIR: string = join(RAWFILE_DIR, 'img')
const READY_DIR: string = join(REPO_ROOT, 'packages', 'data', 'ready')
const PROVENANCE_FILE: string = join(REPO_ROOT, 'packages', 'data', 'provenance.json')

/** 端侧词表规模上限（约 100KB，见设计文档 §4.6 体积预算） */
const VOCAB_TOP_N: number = 12000

/** 嵌入缓存与产物路径（derived 与 .cache 均已 gitignore） */
const CACHE_FILE: string = join(REPO_ROOT, 'packages', 'data', '.cache', 'embeddings.jsonl')
const EMBED_OUT_DIR: string = join(REPO_ROOT, 'packages', 'data', 'derived', 'embeddings')
const RAW_OUT_DIR: string = join(
  REPO_ROOT,
  'harmony',
  'YellowRiverArchive',
  'entry',
  'src',
  'main',
  'resources',
  'rawfile',
  'data'
)

function printIssues(issues: readonly LoadIssue[]): void {
  for (const issue of issues) {
    console.error(`  [${issue.file}]`)
    for (const p of issue.problems) {
      console.error(`      ${p}`)
    }
  }
}

function printDistribution(d: Distribution): void {
  const line = (label: string, rows: readonly { key: string; count: number }[]): void => {
    const body: string = rows.map((r) => `${r.key} ${r.count}`).join('  ｜  ')
    console.log(`  ${label}  ${body}`)
  }
  console.log(`  档案总数  ${d.total}`)
  line('城市分布 ', d.byCity)
  line('时代分布 ', d.byEra)
  line('类型分布 ', d.byType)
  console.log(`  配图总数  ${d.imageCount}  ｜  含诗词条目  ${d.poemCovered}`)
}

function printLintIssues(issues: readonly LintIssue[], level: 'error' | 'warning'): void {
  const selected: LintIssue[] = issues.filter((i) => i.level === level)
  if (selected.length === 0) {
    return
  }
  console.log('')
  console.log(level === 'error' ? '[lint] 硬错误（必须修）' : '[lint] 软提醒（建议修）')
  for (const issue of selected) {
    console.log(`  ${issue.target} ・ ${issue.field}  ${issue.message}`)
  }
}

async function main(): Promise<void> {
  const command: string = process.argv[2] ?? 'build'


  // draft 子命令：为有来源摘录的条目生成 AI 草稿（禁止直接入库）
  if (command === 'draft') {
    const loaded = await loadSites(SITES_DIR)
    const doc = await loadSitesDoc(SITES_INDEX)
    const only: string | undefined = process.argv.find((a) => a.startsWith('--id='))?.slice('--id='.length)
    const p0Only: boolean = !process.argv.includes('--all')

    const targets: DraftTarget[] = doc.sites
      .filter((s) => (only !== undefined ? s.id === only : true))
      .filter((s) => (p0Only ? s.priority === 'P0' : true))
      .map((s) => ({
        id: s.id,
        name: s.name,
        city: s.city,
        era: s.era,
        ...(s.eraRange !== undefined ? { eraRange: s.eraRange } : {}),
        types: s.types,
        level: s.level,
        ...(s.batch !== undefined ? { batch: s.batch } : {}),
        ...(s.notes !== undefined ? { notes: s.notes } : {}),
      }))

    void loaded
    console.log(`[draft] 目标 ${targets.length} 条（${p0Only ? '仅 P0' : '全部'}）`)
    const reports: DraftReport[] = await draftAll(targets, SOURCES_DIR, DRAFTS_DIR)
    const ok: number = reports.filter((r) => r.ok).length
    const skipped: number = reports.filter((r) => r.message.startsWith('缺少来源摘录')).length
    console.log('')
    console.log(`[draft] 成功 ${ok} 条，跳过 ${skipped} 条，失败 ${reports.length - ok - skipped} 条`)
    console.log(`[draft] 产物目录 ${DRAFTS_DIR.replace(REPO_ROOT + '/', '')}（草稿，禁止直接入库）`)
    return
  }

  // lint 子命令：质量体检，不写任何文件
  if (command === 'lint') {
    const phase: 'dev' | 'final' = process.argv.includes('--final') ? 'final' : 'dev'
    const loaded = await loadSites(SITES_DIR)
    const doc = await loadSitesDoc(SITES_INDEX)

    const report: LintReport = await lintAll({
      items: loaded.items,
      allocation: doc.meta.allocation,
      sourcesDir: SOURCES_DIR,
      contentDir: SITES_DIR,
      indexEntries: doc.sites,
      phase,
    })

    const chunks = buildChunks(loaded.items)
    const lexicon: string[] = await loadLexicon(LEXICON)
    const allTerms: string[] = Array.from(
      new Set<string>([...lexicon, ...extractTermsFromItems(loaded.items)])
    )
    const tokenizer: Tokenizer = Tokenizer.create(allTerms)
    const tokenized = chunks.map((c) => ({ ...c, tokens: tokenizer.tokenize(c.text) }))
    const vocab: VocabEntry[] = buildVocab(
      tokenized.map((c) => [...c.tokens]),
      VOCAB_TOP_N
    )

    const extras: LintIssue[] = [...lintChunks(tokenized), ...lintVocab(vocab)]
    const allIssues: LintIssue[] = [...report.issues, ...extras]
    const errorCount: number = allIssues.filter((i) => i.level === 'error').length
    const warningCount: number = allIssues.filter((i) => i.level === 'warning').length

    console.log('[lint] 数据质检')
    console.log(`  阶段 ${phase === 'final' ? '交付期（覆盖度按硬错误计）' : '开发期（覆盖度按提醒计）'}`)
    console.log(`  条目 ${report.stats.items} 条 ｜ 有来源摘录 ${report.stats.itemsWithSource} 条`)
    console.log(`  分块 ${tokenized.length} 个 ｜ 词表 ${vocab.length} 词`)
    console.log(`  查重命中 ${report.stats.ngramHits} 处 ｜ 含占位图条目 ${report.stats.placeholderItems} 条`)
    if (report.stats.itemsWithSource === 0) {
      console.log('')
      console.log('  注意：尚无来源摘录（packages/data/sources/<id>.md），')
      console.log('        本次未执行 n-gram 查重。写作阶段必须补齐摘录文件，否则无法把住抄袭线。')
    }

    printLintIssues(allIssues, 'error')
    printLintIssues(allIssues, 'warning')

    console.log('')
    console.log(`[lint] 硬错误 ${errorCount} 项，软提醒 ${warningCount} 项`)
    if (errorCount > 0) {
      process.exit(1)
    }
    return
  }

  // promote 子命令：把改写通过的条目装配成 sites/<id>.yaml
  if (command === 'promote') {
    const reports: PromoteReport[] = await promoteAll({
      readyDir: READY_DIR,
      sourcesDir: SOURCES_DIR,
      sitesDir: SITES_DIR,
      indexFile: SITES_INDEX,
      provenanceFile: PROVENANCE_FILE,
    })
    console.log('[promote] 条目装配入库')
    for (const r of reports) {
      console.log(`  ${r.ok ? 'OK  ' : 'SKIP'} ${r.id.padEnd(24, ' ')} ${r.message}`)
    }
    const ok = reports.filter((r) => r.ok).length
    console.log(`[promote] 入库 ${ok} 条，跳过 ${reports.length - ok} 条`)
    return
  }

  // rewrite 子命令：把贴源草稿改写成自己的话，机器验收 15 字重合
  if (command === 'rewrite') {
    const limitArg: string | undefined = process.argv.find((a) => a.startsWith('--limit='))?.slice('--limit='.length)
    const reports: RewriteReport[] = await rewriteAll({
      draftsDir: DRAFTS_DIR,
      sourcesDir: SOURCES_DIR,
      outDir: READY_DIR,
      onlyMissing: !process.argv.includes('--redo'),
      ...(limitArg !== undefined ? { limit: Number.parseInt(limitArg, 10) } : {}),
    })
    const ok: number = reports.filter((r) => r.ok).length
    console.log(`[rewrite] 通过 ${ok}/${reports.length}，未过退回人工 ${reports.length - ok}`)
    console.log(`[rewrite] 产物 -> ${READY_DIR.replace(REPO_ROOT + '/', '')}`)
    return
  }

  // sources 子命令：抓公开页面正文，落成来源摘录文件（起草门禁的输入）
  if (command === 'sources') {
    const onlyArg: string | undefined = process.argv.find((a) => a.startsWith('--id='))?.slice('--id='.length)
    const limitArg: string | undefined = process.argv.find((a) => a.startsWith('--limit='))?.slice('--limit='.length)
    const all: boolean = process.argv.includes('--all')
    const reports: SourceReport[] = await fetchSources({
      indexFile: SITES_INDEX,
      sourcesDir: SOURCES_DIR,
      // 默认只补缺口，已存在的摘录不覆盖（人工改过的内容比抓取结果贵）
      onlyMissing: !all,
      ...(onlyArg !== undefined ? { onlyId: onlyArg } : {}),
      ...(limitArg !== undefined ? { limit: Number.parseInt(limitArg, 10) } : {}),
    })
    console.log('[sources] 来源摘录采集')
    for (const r of reports) {
      console.log(`  ${r.status === 'ok' ? 'OK  ' : r.status === 'thin' ? 'THIN' : 'FAIL'} ${r.id.padEnd(22, ' ')} ${r.message}`)
    }
    const ok: number = reports.filter((r) => r.status === 'ok').length
    const thin: number = reports.filter((r) => r.status === 'thin').length
    const fail: number = reports.filter((r) => r.status === 'fail').length
    console.log(`[sources] 可用 ${ok}，偏薄待人工 ${thin}，未取到 ${fail}`)
    return
  }

  // covers 子命令：程序化生成封面卡 + 修正 yaml 占位措辞
  if (command === 'covers') {
    const reports: CoverReport[] = await generateCovers({
      sitesDir: SITES_DIR,
      fontPath: FONT,
      paperPath: PAPER,
      outDir: IMG_DIR,
    })
    let creditFixed: number = 0
    for (const item of (await loadSites(SITES_DIR)).items) {
      const yamlPath: string = join(SITES_DIR, `${item.id}.yaml`)
      try {
        if (fixImageCredit(yamlPath, item.name)) creditFixed++
      } catch {
        // 条目 yaml 缺 images 段时跳过
      }
    }
    const ok: number = reports.filter((r) => r.ok).length
    console.log('[covers] 封面卡生成')
    for (const r of reports) {
      console.log(`  ${r.ok ? 'OK  ' : 'FAIL'} ${r.id.padEnd(22, ' ')} ${r.message}`)
    }
    console.log(`[covers] 成功 ${ok}/${reports.length} 张，yaml 署名修正 ${creditFixed} 个文件`)
    if (ok < reports.length) process.exit(1)
    return
  }

  // sites 子命令：只体检清单台账，不碰正文
  if (command === 'sites') {
    const doc = await loadSitesDoc(SITES_INDEX)
    const report: SitesReport = reportSites(doc, SITES_DIR)
    console.log('[pipeline] 清单体检')
    for (const line of report.lines) {
      console.log(`  ${line}`)
    }
    if (report.problems.length > 0) {
      console.log('')
      console.log('[pipeline] 待处理事项：')
      for (const p of report.problems) {
        console.log(`  - ${p}`)
      }
    } else {
      console.log('')
      console.log('[pipeline] 清单体检全部通过')
    }
    return
  }

  // embed 子命令：只跑嵌入，不重建预置包（供分段试跑与补跑）
  if (command === 'embed') {
    const limitArg: string | undefined = process.argv.find((a) => a.startsWith('--limit='))
    const limit: number | undefined =
      limitArg !== undefined ? Number.parseInt(limitArg.slice('--limit='.length), 10) : undefined

    const loaded = await loadSites(SITES_DIR)
    if (loaded.issues.length > 0) {
      printIssues(loaded.issues)
      console.error('[pipeline] 档案校验未通过，已中止嵌入')
      process.exit(1)
    }

    const chunksForEmbed = buildChunks(loaded.items)
    const report: EmbedReport = await runEmbedding({
      items: loaded.items,
      chunks: chunksForEmbed,
      cacheFile: CACHE_FILE,
      outDir: EMBED_OUT_DIR,
      limit,
    })
    console.log(
      `[embed] 完成：共 ${report.total} 个片段，缓存命中 ${report.cached}，本次编码 ${report.embedded}，失败 ${report.failed}`
    )
    console.log(
      `[embed] 模型 ${report.model} @ ${report.dim} 维 ｜ 耗时 ${(report.elapsedMs / 1000).toFixed(1)}s ｜ token ${report.tokens}`
    )
    console.log(`[embed] 产物 -> ${EMBED_OUT_DIR.replace(REPO_ROOT + '/', '')}`)
    if (report.failed > 0) {
      process.exit(1)
    }
    return
  }

  const { items, issues } = await loadSites(SITES_DIR)
  console.log(`[pipeline] 读取 ${SITES_DIR.replace(REPO_ROOT + '/', '')}`)
  console.log(`[pipeline] 通过校验 ${items.length} 条，问题 ${issues.length} 条`)

  if (issues.length > 0) {
    printIssues(issues)
  }

  if (command === 'verify' && issues.length > 0) {
    console.error('[pipeline] 校验未通过，已中止')
    process.exit(1)
  }

  const distribution: Distribution = computeDistribution(items)
  console.log('[pipeline] 数据分布：')
  printDistribution(distribution)

  if (command === 'status' || command === 'verify') {
    return
  }

  if (items.length === 0) {
    console.error('[pipeline] 没有可用条目，跳过导出')
    process.exit(1)
  }

  const chunks = buildChunks(items)

  // 分词：jieba + 领域词典前向最大匹配
  const lexicon: string[] = await loadLexicon(LEXICON)
  const autoTerms: string[] = extractTermsFromItems(items)
  const allTerms: string[] = Array.from(new Set<string>([...lexicon, ...autoTerms]))
  const tokenizer: Tokenizer = Tokenizer.create(allTerms)
  const tokenized = chunks.map((c) => ({ ...c, tokens: tokenizer.tokenize(c.text) }))
  const vocab: VocabEntry[] = buildVocab(
    tokenized.map((c) => [...c.tokens]),
    VOCAB_TOP_N
  )
  const avgTokens: number =
    tokenized.length > 0
      ? Math.round(tokenized.reduce((sum, c) => sum + c.tokens.length, 0) / tokenized.length)
      : 0

  // 先算相似度再建图：条目间的关系边要由相似度生成，
  // 否则图会是 N 个互不相连的星形，社区发现退化成平凡解
  const similar = buildSimilar(items)
  const graph = buildGraph(items, similar)

  console.log(
    `[pipeline] 分块 ${chunks.length} 个 ｜ 领域词 ${allTerms.length} 条 ｜ 平均 ${avgTokens} 词/片段 ｜ 词表 ${vocab.length} 词`
  )
  console.log(
    `[pipeline] 图谱 ${graph.nodes.length} 节点 / ${graph.edges.length} 连边 ｜ 相似条目 ${similar.length} 条`
  )

  const imageCount: number = items.reduce((sum, i) => sum + i.images.length, 0)
  const result = await exportPreset({
    items,
    chunks: tokenized,
    nodes: graph.nodes,
    edges: graph.edges,
    similar,
    vocab,
    imageCount,
    outDir: RAW_OUT_DIR,
  })

  console.log(
    `[pipeline] 已导出预置包 -> ${RAW_OUT_DIR.replace(REPO_ROOT + '/', '')}（dataVersion ${result.meta.dataVersion}，contentHash ${result.meta.contentHash}）`
  )
  for (const f of result.files) {
    console.log(`      ${f.name}  ${(f.bytes / 1024).toFixed(1)}KB`)
  }
}

main().catch((err: unknown) => {
  console.error('[pipeline] 失败：', err instanceof Error ? err.message : err)
  process.exit(1)
})
